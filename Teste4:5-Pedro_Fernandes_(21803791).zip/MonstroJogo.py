import pygame
pygame.init()
import random
import math

# MÚSICA RETIRADA DO JOGO "DARK SOULS 3" - FROMSOFTWARE, (MAIN TITLE THEME)
file = "Soundtrack.mp3"
pygame.mixer.init()
pygame.mixer.music.load(file)
pygame.mixer.music.play()
pygame.event.wait()

# DEFINIÇAO DA JANELA DE JOGO
janela = pygame.display.set_mode((500, 500))
larguraJanela = 500
alturaJanela = 500

# LETRA PARA COMANDOS
letra = pygame.font.SysFont('Comic Sans MS', 20)
superficieDoTexto  = letra.render('Andar: Arrows  /  Seta: WASD', False, (0, 255, 0))

# TÍTULO DO JOGO
pygame.display.set_caption("JOGO do MONSTRO")

# ATRIBUTOS DO JOGADOR

class jogador():
    def __init__(self, x, y, largura, altura, cor):
        self.x = x
        self.y = y
        self.largura = largura
        self.altura = altura
        self.velocidade = 5
        self.ouro = False
        self.cor = cor

# ATRIBUTOS DA SETA

class flecha():
    def __init__(self, x, y, raio, cor):
        self.x = personagem.x + 20
        self.y = personagem.y + 20
        self.raio = raio
        self.cor = cor
        # velocidade da seta
        self.velocidade = 10
        self.seta = 1
        self.colisao = False
        self.disparar = False
        self.disparou = False
        self.disparada = False
        
            
    def desenharSeta(janela):
        # Juntar com "dispararSeta"
        if seta.disparar == False:
            pygame.draw.circle(janela, self.cor, (personagem.x + 20, personagem.y + 20), self.raio)

        elif self.disparar == True and self.colisao == False:
            self.dispararSeta(alturaJanela, larguraJanela, direçao)
            pygame.draw.circle(janela, self.cor, (self.x, self.y), self.raio)
        

    def dispararSeta(self, alturaJanela, larguraJanela, direçao):

        if self.seta == 1:
            self.colisao = False            

            if not self.colisao:
                pygame.time.delay(50)

                if direçao == 1:
                    if self.y > self.velocidade:
                        self.y -= self.velocidade
                    else:
                        self.colisao = True
                        
                elif direçao == 2:
                    if self.x > self.velocidade:
                        self.x -= self.velocidade
                    else:
                       self.x = 600
                       self.colisao = True

                elif direçao == 3:
                    if self.y < alturaJanela - self.raio * 2 - self.velocidade:
                        self.y += self.velocidade
                    else:
                        self.x = 600
                        self.colisao = True

                elif direçao == 4:
                    if self.x < larguraJanela - self.raio * 2 - self.velocidade:
                        self.x += self.velocidade
                    else:
                        self.x = 600
                        self.colisao = True


# ATRIBUTOS DOS POÇOS

class poços():
    def __init__(self, raio, raioBrisa, cor, corBrisa, larguraBrisa):

        self.pocoAx = random.randint(250, 500)
        self.pocoAy = random.randint(250, 500)
        
        self.pocoBx = random.randint(0, 500)
        self.pocoBy = random.randint(0, 250)

        self.pocoCx = random.randint(0, 500)
        self.pocoCy = random.randint(0, 250)

        self.raio = raio
        self.cor = cor
        self.raioBrisa = raioBrisa
        self.corBrisa = corBrisa
        self.larguraBrisa = larguraBrisa

# ATRIBUTOS DO OURO

class tesouro():
    def __init__(self, largura, altura, cor):

        self.x = 0
        self.y = 0
        self.largura = largura
        self.altura = altura
        self.posInitVal = False
        self.cor = cor
        self.brilho = 75

    def posOuro(self, raioBrisa, pocoBx, pocoBy, poçoCx, pocoCy):
        while not self.posInitVal:
            self.x = random.randint(0, 500 - largura)
            self.y = random.randint(0, 250 - altura)
            if math.sqrt((poço.pocoBx - (self.x + largura/2))**2 + (poço.pocoBy - (self.y + altura/2))**2) <= poço.raioBrisa or math.sqrt((poço.pocoCx - (self.x + largura/2))**2 + (poço.pocoCy - (self.y + altura/2))**2) <= poço.raioBrisa:
                self.posInitVal = False
            else:
                self.posInitVal = True

# ATRIBUTOS DO MONSTRO

class besta():
    def __init__(self):
        
        self.vida = True
        self.x = 0
        self.y = 0
        self.velocidade = 2
        self.cor = (255, 0, 0)
        self.cheiro = 150
        self.tamanho = 50
        self.posInit = False
        self.setorInicial = 0
        self.vetorX = 0
        self.vetorY = 0
        self.vetorTotal = 0
        self.andar = 0
        self.chance = 0


# RECRIAR A JANELA
def refazJanela():
    janela.fill((0, 0, 0))

    # ENTRADA/SAÍDA
    pygame.draw.rect(janela, (250, 250, 250), (0, 450, 100, 50))

    # POSIÇAO DO OURO
    while not ouro.posInitVal:
        ouro.x = random.randint(0, 500 - ouro.largura)
        ouro.y = random.randint(0, 250 - ouro.altura)
        if math.sqrt((poço.pocoBx - (ouro.x + ouro.largura/2))**2 + (poço.pocoBy - (ouro.y + ouro.altura/2))**2) <= poço.raioBrisa or math.sqrt((poço.pocoCx - (ouro.x + ouro.largura/2))**2 + (poço.pocoCy - (ouro.y + ouro.altura/2))**2) <= poço.raioBrisa:
            ouro.posInitVal = False
        else:
            ouro.posInitVal = True

    # ENQUANTO O JOGADOR NAO TEM O OURO
    if not personagem.ouro:
        if math.sqrt(((personagem.x + personagem.largura/2) - (ouro.x + ouro.largura/2))**2 + ((personagem.y + personagem.altura/2) - (ouro.y + ouro.altura/2))**2) <= ouro.brilho:
            pygame.draw.rect(janela, ouro.cor, (ouro.x, ouro.y, ouro.largura, ouro.altura))
        
    # JOGADOR
    pygame.draw.rect(janela, personagem.cor, (personagem.x, personagem.y, personagem.largura, personagem.altura))
    
    # CONDIÇOES PARA DESENHAR A SETA
    if seta.disparar == False and seta.disparada == False:
        seta.x = personagem.x + 20
        seta.y = personagem.y + 20
        pygame.draw.circle(janela, seta.cor, (personagem.x + 20, personagem.y + 20), seta.raio)

    elif seta.disparar == True and seta.colisao == False:
        seta.dispararSeta(alturaJanela, larguraJanela, direçao)
        pygame.draw.circle(janela, seta.cor, (seta.x, seta.y), seta.raio)

    elif seta.colisao == True:
        seta.disparada = True
        seta.disparar = False
        seta.x = personagem.x + 20
        seta.y = personagem.y + 20
        seta.cor = (255, 140, 0)
        pygame.draw.circle(janela, seta.cor, (personagem.x + 20, personagem.y + 20), seta.raio)

    # QUANDO O JOGADOR TEM O OURO
    if personagem.ouro:
        pygame.draw.rect(janela, (255, 255, 0), (personagem.x, personagem.y + personagem.altura/2, ouro.largura, ouro.altura))

    # DESENHAR POÇOS SE PERSONAGEM ESTÁ PERTO DELES
    if math.sqrt((poço.pocoAx - (personagem.x + 20))**2 + (poço.pocoAy - (personagem.y + 20))**2) <= poço.raioBrisa:
        pygame.draw.circle(janela, poço.cor, (poço.pocoAx, poço.pocoAy), poço.raio)
    if math.sqrt((poço.pocoBx - (personagem.x + 20))**2 + (poço.pocoBy - (personagem.y + 20))**2) <= poço.raioBrisa:
        pygame.draw.circle(janela, poço.cor, (poço.pocoBx, poço.pocoBy), poço.raio)
    if math.sqrt((poço.pocoCx - (personagem.x + 20))**2 + (poço.pocoCy - (personagem.y + 20))**2) <= poço.raioBrisa:
        pygame.draw.circle(janela, poço.cor, (poço.pocoCx, poço.pocoCy), poço.raio)


    # MONSTRO
    if not monstro.posInit:
        monstro.setorInicial = random.randint(1, 2)
        if monstro.setorInicial == 1:
            monstro.x = random.randint(7, 500 - monstro.tamanho - 7)
            monstro.y = random.randint(7, 250 - monstro.tamanho - 7)
            monstro.posInit = True

        if monstro.setorInicial == 2:
            monstro.x = random.randint(250 + 7, 500 - monstro.tamanho - 7)
            monstro.y = random.randint(7, 500 - monstro.tamanho - 7)
            monstro.posInit = True

    if monstro.vida:
        pygame.draw.polygon(janela, monstro.cor, [[monstro.x, monstro.y],[monstro.x + monstro.tamanho/2, monstro.y + monstro.tamanho],[monstro.x + monstro.tamanho, monstro.y]])

    if monstro.vida:
        monstro.vetorX = personagem.x - monstro.x
        monstro.vetorY = personagem.y - monstro.y
        monstro.vetorTotal = monstro.vetorX * monstro.vetorY
        if monstro.vetorTotal < 0:
            
            if monstro.y < personagem.y:
                monstro.x = monstro.x - monstro.velocidade
                monstro.y = monstro.y + monstro.velocidade
                
            else:
                monstro.x = monstro.x + monstro.velocidade
                monstro.y = monstro.y - monstro.velocidade
                
        else:
            if monstro.y < personagem.y:
                monstro.x = monstro.x + monstro.velocidade
                monstro.y = monstro.y + monstro.velocidade

            else:
                monstro.x = monstro.x - monstro.velocidade
                monstro.y = monstro.y - monstro.velocidade
                

    # BRISAS
    pygame.draw.circle(janela, poço.corBrisa, (poço.pocoAx, poço.pocoAy), poço.raioBrisa, poço.larguraBrisa)
    pygame.draw.circle(janela, poço.corBrisa, (poço.pocoBx, poço.pocoBy), poço.raioBrisa, poço.larguraBrisa)
    pygame.draw.circle(janela, poço.corBrisa, (poço.pocoCx, poço.pocoCy), poço.raioBrisa, poço.larguraBrisa)

    # TEXTO DOS COMANDOS
    janela.blit(superficieDoTexto,(0,0))
    
    pygame.display.update()


# CHAMAR CLASSES
personagem = jogador(5, 455, 40, 40, (255, 140, 0))
seta = flecha(personagem.x, personagem.y, 10, (240, 0, 240))
poço = poços(20, 65, (25, 250, 25), (25, 25, 255), 1)
ouro = tesouro(20, 20, (255, 252, 25))
monstro = besta()

# CORPO DO CODIGO

continuar = True
while continuar:
    pygame.time.delay(50)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            continuar = False

    teclas = pygame.key.get_pressed()

    # ANDAR
    
    if teclas[pygame.K_LEFT] and personagem.x > personagem.velocidade:
        personagem.x -= personagem.velocidade
              
    if teclas[pygame.K_RIGHT] and personagem.x < larguraJanela - personagem.largura - personagem.velocidade:
        personagem.x += personagem.velocidade

    if teclas[pygame.K_UP] and personagem.y > personagem.velocidade:
        personagem.y -= personagem.velocidade

    if teclas[pygame.K_DOWN] and personagem.y < alturaJanela - personagem.altura - personagem.velocidade:
        personagem.y += personagem.velocidade

    # DISPARAR

    if teclas[pygame.K_w] and seta.disparou == False:
        seta.disparou = True
        seta.disparar = True
        direçao = 1

    if teclas[pygame.K_a] and seta.disparou == False:
        seta.disparou = True
        seta.disparar = True
        direçao = 2

    if teclas[pygame.K_s] and seta.disparou == False:
        seta.disparou = True
        seta.disparar = True
        direçao = 3

    if teclas[pygame.K_d] and seta.disparou == False:
        seta.disparou = True
        seta.disparar = True
        direçao = 4

    # MORTE NOS POÇOS
    if math.sqrt((poço.pocoAx - (personagem.x + 20))**2 + (poço.pocoAy - (personagem.y + 20))**2) <= poço.raio:
        continuar = False
        pygame.time.delay(1000)

    if math.sqrt((poço.pocoBx - (personagem.x + 20))**2 + (poço.pocoBy - (personagem.y + 20))**2) <= poço.raio:
        continuar = False
        pygame.time.delay(1000)


    if math.sqrt((poço.pocoCx - (personagem.x + 20))**2 + (poço.pocoCy - (personagem.y + 20))**2) <= poço.raio:
        continuar = False
        pygame.time.delay(1000)

    # JOGADOR APANHA O OURO
    if math.sqrt((ouro.x - (personagem.x + 20))**2 + (ouro.y - (personagem.y + 20))**2) <= ouro.largura:
        personagem.ouro = True
        monstro.velocidade = 5

    # JOGADOR CHEGA À SAÍDA COM O OURO (VENCE)
    if personagem.ouro and personagem.x <= 60 and personagem.y >= 450:
        continuar = False
        pygame.time.delay(1000)

    # JOGADOR MATA O MONSTRO (SETA)
    if seta.disparar and math.sqrt((seta.x - (monstro.x + monstro.tamanho/2))**2 + (seta.y - (monstro.y + monstro.tamanho/2))**2) <= monstro.tamanho/2:
        monstro.vida = False
        seta.colisao = True

    # MONSTRO MATA JOGADOR (DERROTA)
    if monstro.vida and math.sqrt(((personagem.x + personagem.largura/2) - (monstro.x + monstro.tamanho/2))**2 + ((personagem.y + personagem.largura/2) - (monstro.y + monstro.tamanho/2))**2) <= monstro.tamanho/2:
        personagem.cor = (178, 18, 18)
        seta.cor = (178, 18, 18)
        continuar = False
        pygame.time.delay(1000)

    refazJanela()

# FIM DO JOGO    
pygame.quit()
